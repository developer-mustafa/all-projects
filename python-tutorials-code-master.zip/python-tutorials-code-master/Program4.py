# Basic Numerical operations -> +, -, *, /, % (modulus) , // (floor) , ** (exponential)
num1 = 5
num2 = 4

result = num1 + num2
print("Addition =  ", result)

result = num1 - num2
print("Subtraction =  ", result)

result = num1 * num2
print("Multiplication =  ", result)

result = num1 / num2
print("Division =  ", result)

result = num1 % num2
print("Remainder =  ", result)

result = num1 ** num2
print("Exponential =  ", result)

result = num1 // num2
print("Floor =  ", result)