# conditional statement - > if, else statement

# pass/fail program
marks = int(input("Enter your marks : "))
if marks >= 33:
    print("Pass")
else:
    print("Fail")

# even/odd program
num = int(input("Enter a number : "))
if num % 2 == 0:
    print("Even")
else:
    print("Odd")