# Loop control statement -> while loop, for loop
# while loop

# print 1 to 100
num = 1
while num <= 100:
    print(num, end=" ")
    num = num + 1
print("end")

# print all the even numbers from 1 to 100
num = 2
while num <= 100:
    print(num, end=" ")
    num = num + 2
print("end")

# print all the odd numbers from 1 to 100
num = 1
while num <= 100:
    print(num, end=" ")
    num = num + 2
print("end")