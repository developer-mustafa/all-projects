# Zip Function
roll = [101,102,103]
name = ["Anisul Islam", "Rabeya Begum", "Linkon Talukdar"]
# (roll,name)
# combine 2 list and make one using zip function
print(list(zip(roll,name)))
print(list(zip(roll,name,"ABC")))