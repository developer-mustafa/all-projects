# type casting
num1 = input("Enter First Number : ")
num2 = int(input("Enter Second Number : "))
sum = int(num1) + num2
print("Sum is : ", sum)