# range function in python
# range will generated a set of numbers
numbers = list(range(10))
print(numbers)
print(numbers[2])

# starting and end point can be set
numbers = list(range(5, 11))
print(numbers)

# starting, end point and interval can be set
numbers = list(range(2, 100, 2))
print(numbers)