# Variables and data types

# before using variables
# print("Anisul Islam has a YouTube Channel")
# print("He studies in Finland")
# print ("Finland is the safest and happiest country in the world")
# print("Anisul Islam is 30 years old now")
# print("His Bachelor CGPA is 3.92 out of 4")

# after using variables. variables helps us to reuse the data and change it whenever necessary
name = "Anisul Islam"
countryName = "Finland"
age = 30
cgpa = 3.92
print(name + " has a YouTube Channel")
print("He studies in "+ countryName)
print (countryName + " is the safest and happiest country in the world")
print(name + " is ", age , " years old now")
print("His Bachelor CGPA is ", cgpa , " out of 4")