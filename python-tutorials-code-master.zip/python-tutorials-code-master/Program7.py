# Area of a shape

# Area of triangle
base = float(input("Enter base = "))
height = float(input("Enter height = "))
area = 0.5 * base * height
print("Area of triangle = ", area)

# Area of circle
radius = float(input("Enter radius = "))
area = 3.1416 * radius * radius
print("Area of circle = ", area)