# Getting User input

name = input("Enter your Name : ")
age = input("Enter your Age : ")
cgpa = input("Enter your CGPA : ")

print("Student Information")
print("---------------------")
print("Name : "+ name)
print("Age :  "+ age)
print("CGPA : "+ cgpa)