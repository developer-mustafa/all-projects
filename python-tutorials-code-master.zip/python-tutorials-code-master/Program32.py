# introduction to function


def add1(a, b):
    sum = a + b
    print(sum)


def add2(a, b, c):
    sum = a + b + c
    print(sum)


def sub(a, b):
    result = a - b
    print(result)


def message():
    print("hello everyone")


add1(10, 20)
add2(10, 20, 30)
sub(20, 10)
message()