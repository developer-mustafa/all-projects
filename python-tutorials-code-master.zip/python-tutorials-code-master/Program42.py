# How to write in a file  (python)

file = open("student.txt","a")


file.write("\nRobiul Islam - Physics")


file.close()