# Math Related Library functions
from math import *
print(max(5,3))
print(min(5,3))
print(pow(5,3))
print(sqrt(25))
print(round(5.3))
print(round(5.8))
print(floor(5.3))
print(ceil(5.3))
