# Loop - for loop
'''
numbers = [10,20,30,40,50,60,70,80]
print(numbers)
i = 0
while i < len(numbers):
    print(numbers[i])
    i = i + 1
print("End")
'''

# printing all the elements using for loop
numbers = [10,20,30,40,50,60,70,80]
for x in numbers:
    print(x)

# finding the sum of all numbers
sum = 0
for x in numbers:
    sum = sum + x
print("sum is : ", sum)

