# Relational operators - >,<,>=,<=, ==, != and Boolean data types -> True / False

print(20>10)
print(20>=10)
print(20>=20)

print(20<10)
print(20<=10)
print(20<=20)

print(20==20)
print(20!=20)