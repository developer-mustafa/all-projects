print(105)
print(10.5)
print("Welcome to Python ! This is Anisul Islam")