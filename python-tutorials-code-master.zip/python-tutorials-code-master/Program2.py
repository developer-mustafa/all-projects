# This is a single line comment
# Backslash characters and comments
'''
    This
    is an
    example of multiple line comment

'''
# print("Name : Anisul Islam")
# print("Address : Sylhet, Bangladesh")
# print("01710444700")
print("Name : Anisul Islam \nAddress : Sylhet, Bangladesh\n01710444700")
print("1\t2")