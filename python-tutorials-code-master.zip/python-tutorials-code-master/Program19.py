# break and continue keyword

# break program
print("Break program : ", end="")
i = 1
while i <= 100:
    if i == 20:
        break
    print(i, end=" ")
    i = i + 1

'''
# continue program
print("Continue program : ", end="")
i = 1
while i <= 100:
    if i == 20:
        continue
    print(i, end=" ")
    i = i + 1
'''
