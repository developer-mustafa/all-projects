// find sum of 1-10 using for loop
public class Assignment10 {
  public static void main(String[] args) {
    
  }
}
