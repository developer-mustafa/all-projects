// if,else if, else program
public class Program12 {
  public static void main(String[] args) {
    int number = 12;
    if(number>0){
      System.out.println("Positive");
    }else if(number<0){
      System.out.println("Negative");
    }else{
      System.out.println("Zero");
    }
  }
}
