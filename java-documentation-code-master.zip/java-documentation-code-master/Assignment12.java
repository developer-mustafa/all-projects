// print sum of odd numbers from m-n
public class Assignment12 {
  public static void main(String[] args) {
    
  }
}
