public class Program20 {
  public static void main(String[] args) {
    int i=1;
    do{
      System.out.println(i);
      i+=1; // i=i+1 or i++
    }while(i<=100);
  }
}
