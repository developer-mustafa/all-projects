
// A program to print your info
// Understand the program flow
// keywords in Java - Keywords are reserved words and also in small letters
// How to create a class, function
// How to print in Java - use System.out.Println() or print() 
class Program1 {
  public static void main(String[] args) {
    System.out.println("Name: Anisul Islam");
    System.out.println("Anisul Islam has completed his M.Sc. in Software, Web and Cloud");
    System.out.println("Anisul Islam is currently working as a  Full-stack Instructor at Integrify, Finland");
  }
}