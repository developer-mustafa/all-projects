// java program phases
/*
 * step 1: Text Editor (.java)
 * step 2: Compile (javac): comple the .java and create Byte code (.class) which is machine readable
 * step 3: Load: Class loader load class in memory
 * step 4: Verify: Class loader verify the class
 * step 5: Execute: JVM excutes .class file 
 * 
 */

