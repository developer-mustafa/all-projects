public class Program17 {
  public static void main(String[] args) {
    int x=20, y=10;

    System.out.println(Math.max(x,y));
    System.out.println(Math.min(x,y));
    System.out.println(Math.abs(-10));
    System.out.println(Math.pow(2,3));
    System.out.println(Math.sqrt(25));
    System.out.println(Math.round(25.57));
    System.out.println(Math.PI);
    System.out.println(Math.PI);

    // random number between 1-5
    System.out.println((Math.floor(Math.random()*5) + 1));
  }
}
