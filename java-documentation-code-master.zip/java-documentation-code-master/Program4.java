/*
 * Learning outcomes
 * variable declaration
 * variable initalization
 * dynamic initialization
 * data types
 */
public class Program4 {
  public static void main(String[] args) {

    // declaring variables for a student
    String name;
    int id, age;
    double gpa;
    boolean isRegisted;

    // initializing variables for a student
    name = "Anisul Islam";
    id = 1302020017;
    age = 25;
    gpa = 3.92;
    isRegisted = true;

    // printing variables
    System.out.println("Student Information");
    System.out.println("--------------------");
    System.out.println("Name: "+name);
    System.out.println("ID: "+id);
    System.out.println("Age: "+age);
    System.out.println("GPA: "+gpa);
    System.out.println("Registered: "+isRegisted);
  }
}
