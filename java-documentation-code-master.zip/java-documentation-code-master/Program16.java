// ternary/conditional operator exp1 ? exp2 : exp3
public class Program16 {
  public static void main(String[] args) {
    int number = 20;
    String result = number%2==0 ? "even" : "odd";
    System.out.println(result);
  }
}
