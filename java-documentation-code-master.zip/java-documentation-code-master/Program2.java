// Escape sequence - a special character followed by backslash. sometimes it is called as backshalsh character
// example -> \b, \t, \n, \", \', \\

class Program2{
  public static void main(String[] args){
    System.out.print("Name: \t\tAnisul Islam\n");
    System.out.println("Education: \tM.Sc. in Software, Web and Cloud");
    System.out.println("Profession: \tFull-stack trainer at Integrify, Finland");
    System.out.println("Passion: \t\"I love coding & teaching\"");
  }
}