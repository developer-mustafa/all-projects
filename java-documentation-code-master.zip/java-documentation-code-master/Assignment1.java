/*
 * Assignment-1
 * create a class called Product
 * create a main method
 * print the following data in main method


 id: 101,
title: iphone15,
price: 1895 euros,
description: perfect product with best image quality,
category: phone,
 */