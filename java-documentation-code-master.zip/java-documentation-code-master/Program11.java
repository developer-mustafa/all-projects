// if,else program
public class Program11 {
  public static void main(String[] args) {
    int number = 12;
    if(number%2==0){
      System.out.println("Even");
    }else{
      System.out.println("Odd");
    }
  }
}
