// find nth fibonacci number
import java.util.Scanner;
public class Assignment13 {
  public static void main(String[] args) {
    try (Scanner input = new Scanner(System.in)) {

      System.out.print("which fibonacci number you want to see? ");
      int n = input.nextInt();

     
    }
  }
}
 