//A program to demonstrate while loop
// while loop syntax
var i = 1;
while (i <= 10) {
  document.write("Bangladesh" + "<br>");
  i++;
}

document.write("End of for loop");

// sum of numbers 1+2+..+100
var sum = 0;
var x = 1;
while (x <= 100) {
  sum = sum + x;
  x++;
}
document.write(sum);
