// Area of various shapes
//Area of triangel

//getting user input for base
var base = parseFloat(prompt("Enter Base = "));

//getting user input for height
var height = parseFloat(prompt("Enter Height = "));

//calculating area
var area = 0.5 * base * height;

//printing area
document.write("Area of triangle = " + area);
