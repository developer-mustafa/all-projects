document.cookie = "username=anisul; expires= Mon, 23 Feb 2022 20:27:00 GMT";

console.log(document.cookie);
