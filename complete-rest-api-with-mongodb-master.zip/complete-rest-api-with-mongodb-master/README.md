# complete-rest-api-with-mongodb

## API Link: https://rest-api-mongodb-2022.herokuapp.com
- GET all users - /api/users
- GET a single user - /api/users/:id
- Create an user -  /api/users/  
- update (patch) a single user - /api/users/:id 
- delete an user - /api/users/:id
