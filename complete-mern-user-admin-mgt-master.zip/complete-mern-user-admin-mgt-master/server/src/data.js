const data = {
  users: [
    {
      name: 'anisul islam',
      email: 'anisul2010@yahoo.co.uk',
      password: '123456',
      phone: '04055566',
    },
    // {
    //   userName: 'david beckham',
    //   userEmail: 'david@gmail.com',
    //   userPassword: '123456',
    //   userPhone: '04055522',
    // },
  ],
};

module.exports = data;
