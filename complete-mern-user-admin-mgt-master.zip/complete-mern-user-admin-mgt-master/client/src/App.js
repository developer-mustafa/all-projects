import React from 'react';

import Index from './routes';

const App = () => {
  return <Index />;
};

export default App;
