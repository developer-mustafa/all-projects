export { Home } from './Home';
export { Login } from './Login';
export { Register } from './Register';
export { Activate } from './Activate';
export { Profile } from './Profile';
