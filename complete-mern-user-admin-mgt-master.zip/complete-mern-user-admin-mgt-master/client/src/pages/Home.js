import React from 'react';
import Google from '../components/Google';

export const Home = () => {
  return (
    <div>
      <h1>Home Page</h1>
      <Google />
    </div>
  );
};
