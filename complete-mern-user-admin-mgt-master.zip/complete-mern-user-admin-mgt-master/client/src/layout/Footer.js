import React from 'react';

const Footer = () => {
  return (
    <footer className="center">
      <p>Copyright by &copy;Anisul Islam</p>
    </footer>
  );
};

export default Footer;
