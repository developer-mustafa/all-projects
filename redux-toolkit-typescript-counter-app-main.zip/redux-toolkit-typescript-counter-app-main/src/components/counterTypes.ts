export type initialStateType = {
  count: number;
};
