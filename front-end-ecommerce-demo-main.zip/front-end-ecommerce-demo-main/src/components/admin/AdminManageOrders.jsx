import React from 'react';

const AdminManageOrders = () => {
  return (
    <div>
      <h2>List of Orders: include update shipping status</h2>
    </div>
  );
};

export default AdminManageOrders;
