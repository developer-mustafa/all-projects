import React from 'react';

const AdminManageCategories = () => {
  return (
    <div>
      <h2>Create Category</h2>
      <h2>List of categories: include Edit and Delete</h2>
    </div>
  );
};

export default AdminManageCategories;
