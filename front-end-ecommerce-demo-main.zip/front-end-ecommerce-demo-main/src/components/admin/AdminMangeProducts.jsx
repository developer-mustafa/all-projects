import React from 'react';

const AdminMangeProducts = () => {
  return (
    <div>
      <h2>Create Product</h2>
      <h2>List of Products: include Edit and Delete</h2>
    </div>
  );
};

export default AdminMangeProducts;
