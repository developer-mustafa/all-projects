import React from 'react';

const UserManageOrder = () => {
  return (
    <div>
      <h2>User Manage Orders here</h2>
    </div>
  );
};

export default UserManageOrder;
