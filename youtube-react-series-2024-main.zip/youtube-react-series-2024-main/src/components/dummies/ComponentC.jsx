import React from 'react';

const ComponentC = () => {
  return (
    <div>
      <h2>Component C</h2>
    </div>
  );
};

export default ComponentC;
