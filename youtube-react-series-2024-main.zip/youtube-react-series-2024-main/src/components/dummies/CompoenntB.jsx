import React from 'react';
import ComponentE from './ComponentE';

const CompoenntB = () => {
  return (
    <div>
      <ComponentE />
    </div>
  );
};

export default CompoenntB;
