import React from 'react';

const ComponentE = () => {
  return (
    <div>
      <h2>Component E</h2>
    </div>
  );
};

export default ComponentE;
