import React from 'react';

const Footer = () => {
  return (
    <footer>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam, non?
      </p>
    </footer>
  );
};

export default Footer;
