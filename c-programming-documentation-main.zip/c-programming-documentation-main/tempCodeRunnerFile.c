printf("%d\n", numbers[0]);
  printf("%d\n", numbers[1]);
  printf("%d\n", numbers[2]);
  printf("%d\n", numbers[3]);
  printf("%d\n", numbers[4]);