# How to run the project

- first clone, go to root directory
- npm install
- run the JSON server `npx json-server -p 3001 -w database/db.json`
- run the app `npm run dev`
