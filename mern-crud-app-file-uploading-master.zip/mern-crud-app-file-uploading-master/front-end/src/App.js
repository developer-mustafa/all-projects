import React from "react";

import "./App.css";
import Index from "./routes";

const App = () => {
  return (
    <div className="App">
      <Index />
    </div>
  );
};

export default App;
