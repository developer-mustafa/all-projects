# CRUD MERN-STACK APP: blog posts

- create the api
- use it from front end
