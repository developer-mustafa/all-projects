export const products = [
  {
    id: 1,
    title: "iPhone 10",
    price: 400,
  },
  {
    id: 2,
    title: "iPhone 14",
    price: 1300,
  },
];
